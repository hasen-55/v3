# cli.py

import argparse
import asyncio
from core.scanner import Scanner

def load_ips(file_path):
    ips = []
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line and not line.startswith('#'):
                ips.append(line)
    return ips

def main():
    parser = argparse.ArgumentParser(description="VoIP Vulnerability Scanner CLI")
    parser.add_argument('-m', '--module', required=True, help="Module to run (e.g. path_traversal, lfi)")
    parser.add_argument('-i', '--ip-list', required=True, help="File with list of IPs (can include port with colon)")
    parser.add_argument('-p', '--port', type=int, default=80, help="Default port if not specified with IP")
    args = parser.parse_args()

    ips = load_ips(args.ip_list)
    scanner = Scanner(ips=ips, port=args.port, module_name=args.module)

    asyncio.run(scanner.run())

if __name__ == "__main__":
    main()
