# core/utils.py

import os

def save_report(ip, port, data):
    os.makedirs("reports", exist_ok=True)
    filename = f"reports/{ip}_{port}.txt"
    with open(filename, "w", encoding="utf-8") as f:
        f.write(data)
