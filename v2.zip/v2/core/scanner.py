# core/scanner.py

import asyncio
from modules import path_traversal, lfi, rce, default_creds

class Scanner:
    def __init__(self, ips, port, module_name):
        """
        ips: قائمة عناوين IP مع البورت أو بدون
        port: بورت افتراضي
        module_name: اسم الموديل الذي سيتم تشغيله (مثل 'path_traversal')
        """
        self.ips = ips
        self.port = port
        self.module_name = module_name

        # ربط الموديل المطلوب
        self.module = self._get_module(module_name)

    def _get_module(self, name):
        modules_map = {
            'path_traversal': path_traversal,
            'lfi': lfi,
            'rce': rce,
            'default_creds': default_creds,
        }
        return modules_map.get(name)

    async def _scan_ip(self, ip_port):
        if ':' in ip_port:
            ip, port = ip_port.split(':')
            port = int(port)
        else:
            ip = ip_port
            port = self.port

        if not self.module:
            print(f"[!] Module {self.module_name} not found!")
            return

        # استدعاء الموديل بطريقة async
        try:
            result = await self.module.run(ip, port)
            if result:
                print(f"[+] Vulnerability found on {ip}:{port}:\n{result}\n")
        except Exception as e:
            print(f"[-] Error scanning {ip}:{port} -> {e}")

    async def run(self):
        tasks = [self._scan_ip(ip_port) for ip_port in self.ips]
        await asyncio.gather(*tasks)
