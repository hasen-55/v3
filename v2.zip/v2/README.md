# VoIPScanner

مشروع لفحص ثغرات أنظمة VoIP الشائعة مثل Path Traversal, LFI, RCE, Default Credentials.

## المتطلبات

- Python 3.8+
- مكتبات: aiohttp, rich

## طريقة الاستخدام

1. ثبت المكتبات:

